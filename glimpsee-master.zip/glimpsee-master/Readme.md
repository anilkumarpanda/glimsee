```
.
├── PostDeployScripts
├── image-analysis
├── messages
│   └── node_modules
├── photos
│   ├── 2016
│   └── 2017
└── text-analysis
```


Get `photos\` from Slack